<?php
namespace GroceryCrud\Core\Redirect;

interface RedirectResponseInterface {

    /**
     * @return string
     */
    public function getUrl();
}